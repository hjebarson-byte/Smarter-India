using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SpendSmart.Views.Home
{
    public class ExpensesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
