using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SpendSmart.Views.Home
{
    public class CreateEditExpenseModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
